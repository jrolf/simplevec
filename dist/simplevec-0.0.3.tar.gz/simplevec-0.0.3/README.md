

![CGEM Logo](https://github.com/jrolf/simplevec/blob/main/images/THINK_DEV.jpeg)

# SimpleVec Model Demo

## Introduction

A Hello World demonstration of using simplevec to create embeddings for a RecSys simulation.



